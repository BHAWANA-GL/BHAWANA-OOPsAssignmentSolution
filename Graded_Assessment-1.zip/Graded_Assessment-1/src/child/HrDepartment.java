package child;

import module.Super;

public class HrDepartment extends Super {
	public String departmentName() {
		return "HR Department";
	}

	public String getTodaysWork() {
		return "Fill today's worksheet and mark your attendence";
	}

	public String getWorkDeadline() {
		return "Complete by EOD";
	}

	public String doActivity() {
		return "team Lunch";
	}
}
